///////////////////////////////////////////////////////////////////////////////
// maincode.cpp
// ============
// gets called when application is launched - initializes GLEW, GLFW
//
// AUTHOR: Jordan Walker
// CS-330 - Aug 15th, 2025
///////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <cstdlib>

#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "SceneManager.h"
#include "ShaderManager.h"

// mouse state
float lastX = 400, lastY = 300;
bool firstMouse = true;
float yaw = -90.0f, pitch = 0.0f;
SceneManager* gScene = nullptr;

// mouse look
void mouse_callback(GLFWwindow* window, double xpos, double ypos) {
    if (firstMouse) { lastX = (float)xpos; lastY = (float)ypos; firstMouse = false; }
    float xoffset = (float)xpos - lastX;
    float yoffset = lastY - (float)ypos;
    lastX = (float)xpos; lastY = (float)ypos;

    float sens = 0.1f;
    xoffset *= sens; yoffset *= sens;
    yaw += xoffset; pitch += yoffset;
    if (pitch > 89.0f) pitch = 89.0f;
    if (pitch < -89.0f) pitch = -89.0f;

    glm::vec3 f;
    f.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
    f.y = sin(glm::radians(pitch));
    f.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
    gScene->cameraFront = glm::normalize(f);
}

// mouse wheel
void scroll_callback(GLFWwindow* window, double, double yoffset) {
    gScene->fov -= (float)yoffset;
    if (gScene->fov < 1.0f) gScene->fov = 1.0f;
    if (gScene->fov > 45.0f) gScene->fov = 45.0f;
}

int main() {
    if (!glfwInit()) { std::cerr << "Failed to init GLFW\n"; return EXIT_FAILURE; }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_COMPAT_PROFILE);

    GLFWwindow* window = glfwCreateWindow(800, 600, "CS330 Final Project", nullptr, nullptr);
    if (!window) { std::cerr << "Failed to create window\n"; glfwTerminate(); return EXIT_FAILURE; }

    glfwMakeContextCurrent(window);
    glewExperimental = GL_TRUE;
    if (glewInit() != GLEW_OK) { std::cerr << "Failed to init GLEW\n"; return EXIT_FAILURE; }

    glViewport(0, 0, 800, 600);

    ShaderManager shaderManager;
    SceneManager scene(&shaderManager);
    gScene = &scene;

    scene.PrepareScene();

    glfwSetCursorPosCallback(window, mouse_callback);
    glfwSetScrollCallback(window, scroll_callback);
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    while (!glfwWindowShouldClose(window)) {
        glfwPollEvents();

        // keys
        float speed = 0.1f;
        if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) scene.cameraPos += speed * scene.cameraFront;
        if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) scene.cameraPos -= speed * scene.cameraFront;
        if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) scene.cameraPos -= glm::normalize(glm::cross(scene.cameraFront, scene.cameraUp)) * speed;
        if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) scene.cameraPos += glm::normalize(glm::cross(scene.cameraFront, scene.cameraUp)) * speed;
        if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) scene.cameraPos += speed * scene.cameraUp;
        if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) scene.cameraPos -= speed * scene.cameraUp;

        // projection toggle
        if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS) scene.SetProjectionMode(false);
        if (glfwGetKey(window, GLFW_KEY_O) == GLFW_PRESS) scene.SetProjectionMode(true);

        scene.RenderScene();
        glfwSwapBuffers(window);
    }

    glfwTerminate();
    return 0;
}
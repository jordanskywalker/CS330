///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// Handles drawing and lighting in the 3D scene
//
// AUTHOR: Jordan Walker
// CS-330 - Aug 15th, 2025
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <iostream>
#include <GL/glew.h>

// constructor to load all textures
SceneManager::SceneManager(ShaderManager* pShaderManager) {
    m_pShaderManager = pShaderManager;
    stbi_set_flip_vertically_on_load(true);

    floorTexture = LoadTexture("textures/floor.jpg");
    wallTexture = LoadTexture("textures/wall.jpg");
    cubeTexture = LoadTexture("textures/cube.jpg");
    texLaptop = LoadTexture("textures/laptop.jpg");
    texMetal = LoadTexture("textures/metal.jpg");
}

SceneManager::~SceneManager() {}

// loads texture from file
GLuint SceneManager::LoadTexture(const char* file) {
    int w = 0, h = 0, n = 0;
    unsigned char* data = stbi_load(file, &w, &h, &n, 0);
    if (!data) {
        std::cout << "Failed to load texture: " << file << "\n";
        return 0;
    }

    GLuint id = 0;
    glGenTextures(1, &id);
    glBindTexture(GL_TEXTURE_2D, id);
    GLenum fmt = (n == 4) ? GL_RGBA : GL_RGB;
    glTexImage2D(GL_TEXTURE_2D, 0, fmt, w, h, 0, fmt, GL_UNSIGNED_BYTE, data);
    glGenerateMipmap(GL_TEXTURE_2D);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    stbi_image_free(data);
    return id;
}

// sets up OpenGL rendering settings
void SceneManager::PrepareScene() {
    glEnable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_NORMALIZE);
    glClearColor(0, 0, 0, 1);
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_TRUE);

    GLfloat spec[4] = { 1, 1, 1, 1 };
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, spec);
    glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, 64.0f);
}

// main function that draws the entire scene
void SceneManager::RenderScene() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // setup projection
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glm::mat4 proj = orthographic
        ? glm::ortho(-5.0f, 5.0f, -5.0f, 5.0f, 0.1f, 100.0f)
        : glm::perspective(glm::radians(fov), 800.0f / 600.0f, 0.1f, 100.0f);
    glLoadMatrixf(glm::value_ptr(proj));

    // setup view matrix
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glm::mat4 view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);

    float deskY = -0.95f;

    // lamp size variables
    float baseH = 0.05f, baseW = 0.18f, baseD = 0.18f;
    float postH = 0.65f, postS = 0.06f;
    float armL = 0.55f, armS = 0.05f;
    float headW = 0.22f, headH = 0.16f, headD = 0.22f;

    // lamp position
    glm::vec3 lampBasePos = glm::vec3(-1.5f, deskY, -0.55f);

    // lamp segment positions
    float postCenterY = deskY + baseH + postH * 0.5f;
    float armCenterY = deskY + baseH + postH - armS * 0.5f;
    float headCenterY = armCenterY + headH * 0.10f;

    glm::vec3 postCenter = glm::vec3(lampBasePos.x, postCenterY, lampBasePos.z);
    glm::vec3 armCenter = glm::vec3(lampBasePos.x + postS * 0.5f + armL * 0.5f, armCenterY, lampBasePos.z);
    glm::vec3 headCenter = glm::vec3(armCenter.x + armL * 0.5f + headW * 0.5f, headCenterY, lampBasePos.z);

    glEnable(GL_LIGHTING);

    // ambient scene light
    glEnable(GL_LIGHT0);
    {
        GLfloat pos[] = { 0.0f, 5.0f, 5.0f, 1.0f };
        GLfloat amb[] = { 0.2f, 0.2f, 0.2f, 1.0f };
        GLfloat dif[] = { 0.6f, 0.6f, 0.6f, 1.0f };
        GLfloat spec[] = { 0.3f, 0.3f, 0.3f, 1.0f };
        glLightfv(GL_LIGHT0, GL_POSITION, pos);
        glLightfv(GL_LIGHT0, GL_AMBIENT, amb);
        glLightfv(GL_LIGHT0, GL_DIFFUSE, dif);
        glLightfv(GL_LIGHT0, GL_SPECULAR, spec);
    }

    // green spotlight from lamp
    glEnable(GL_LIGHT1);
    {
        glm::mat4 headM = glm::translate(glm::mat4(1.0f), headCenter);
        headM = glm::rotate(headM, glm::radians(65.0f), glm::vec3(0, 0, 1));
        glPushMatrix();
        glLoadMatrixf(glm::value_ptr(view * headM));
        GLfloat pos[] = { 0.0f, 0.0f, 0.0f, 1.0f };
        GLfloat dir[] = { 0.0f, -1.0f, 0.0f };
        glLightfv(GL_LIGHT1, GL_POSITION, pos);
        glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, dir);
        glPopMatrix();

        GLfloat amb[] = { 0.0f, 0.0f, 0.0f, 1.0f };
        GLfloat dif[] = { 0.0f, 7.0f, 0.0f, 1.0f };  // brighter green
        GLfloat spec[] = { 0.0f, 7.0f, 0.0f, 1.0f };
        glLightf(GL_LIGHT1, GL_SPOT_CUTOFF, 80.0f);
        glLightf(GL_LIGHT1, GL_SPOT_EXPONENT, 1.0f);
        glLightf(GL_LIGHT1, GL_CONSTANT_ATTENUATION, 1.0f);
        glLightf(GL_LIGHT1, GL_LINEAR_ATTENUATION, 0.01f);
        glLightf(GL_LIGHT1, GL_QUADRATIC_ATTENUATION, 0.001f);
        glLightfv(GL_LIGHT1, GL_AMBIENT, amb);
        glLightfv(GL_LIGHT1, GL_DIFFUSE, dif);
        glLightfv(GL_LIGHT1, GL_SPECULAR, spec);
    }

    glDisable(GL_LIGHT2);

    glEnable(GL_COLOR_MATERIAL);
    glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);

    // desk top
    glBindTexture(GL_TEXTURE_2D, floorTexture);
    {
        glm::mat4 m = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -1.0f, 0.0f));
        m = glm::scale(m, glm::vec3(4.0f, 0.1f, 2.5f));
        glLoadMatrixf(glm::value_ptr(view * m));
        glNormal3f(0, 1, 0);
        DrawCube(1.0f);
    }

    // desk legs
    float legHeight = 0.8f;
    float legWidth = 0.1f;
    glm::vec3 legPositions[4] = {
        glm::vec3(-1.9f, -1.0f - legHeight / 2, -1.2f),
        glm::vec3(1.9f, -1.0f - legHeight / 2, -1.2f),
        glm::vec3(-1.9f, -1.0f - legHeight / 2, 1.2f),
        glm::vec3(1.9f, -1.0f - legHeight / 2, 1.2f)
    };
    for (int i = 0; i < 4; i++) {
        glm::mat4 m = glm::translate(glm::mat4(1.0f), legPositions[i]);
        m = glm::scale(m, glm::vec3(legWidth, legHeight, legWidth));
        glLoadMatrixf(glm::value_ptr(view * m));
        glNormal3f(0, 1, 0);
        DrawCube(1.0f);
    }

    // back wall
    glBindTexture(GL_TEXTURE_2D, wallTexture);
    {
        glm::mat4 m = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.5f, -1.0f));
        m = glm::scale(m, glm::vec3(12.0f, 6.0f, 0.1f));
        glLoadMatrixf(glm::value_ptr(view * m));
        glNormal3f(0, 0, 1);
        DrawCube(1.0f);
    }

    // laptop base
    glBindTexture(GL_TEXTURE_2D, texLaptop);
    {
        glm::mat4 m = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, deskY + 0.025f, -0.52f));
        m = glm::scale(m, glm::vec3(1.60f, 0.05f, 0.90f));
        glLoadMatrixf(glm::value_ptr(view * m));
        DrawCube(1.0f);
    }

    // laptop screen frame
    {
        glm::mat4 m = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, deskY + 0.52f, -0.38f));
        m = glm::scale(m, glm::vec3(1.20f, 0.80f, 0.06f));
        glLoadMatrixf(glm::value_ptr(view * m));
        DrawCube(1.0f);
    }

    // laptop screen black
    glDisable(GL_TEXTURE_2D);
    glColor3f(0.02f, 0.02f, 0.02f);
    {
        glm::mat4 m = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, deskY + 0.52f, -0.35f));
        m = glm::scale(m, glm::vec3(0.95f, 0.65f, 0.01f));
        glLoadMatrixf(glm::value_ptr(view * m));
        DrawCube(1.0f);
    }
    glEnable(GL_TEXTURE_2D);
    glColor3f(1, 1, 1);

    // lamp build
    glBindTexture(GL_TEXTURE_2D, texMetal);
    {
        glm::mat4 m;

        // base
        m = glm::translate(glm::mat4(1.0f), glm::vec3(lampBasePos.x, deskY + baseH * 0.5f, lampBasePos.z));
        m = glm::scale(m, glm::vec3(baseW, baseH, baseD));
        glLoadMatrixf(glm::value_ptr(view * m));
        DrawCube(1.0f);

        // post
        m = glm::translate(glm::mat4(1.0f), postCenter);
        m = glm::scale(m, glm::vec3(postS, postH, postS));
        glLoadMatrixf(glm::value_ptr(view * m));
        DrawCube(1.0f);

        // arm
        m = glm::translate(glm::mat4(1.0f), armCenter);
        m = glm::scale(m, glm::vec3(armL, armS, armS));
        glLoadMatrixf(glm::value_ptr(view * m));
        DrawCube(1.0f);

        // head glow
        GLfloat emission[] = { 0.0f, 1.0f, 0.0f, 1.0f };
        glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, emission);

        // head
        m = glm::translate(glm::mat4(1.0f), headCenter);
        m = glm::rotate(m, glm::radians(65.0f), glm::vec3(0, 0, 1));
        m = glm::scale(m, glm::vec3(headW, headH, headD));
        glLoadMatrixf(glm::value_ptr(view * m));
        DrawCube(1.0f);

        // turn off glow
        GLfloat noEmission[] = { 0.0f, 0.0f, 0.0f, 1.0f };
        glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, noEmission);
    }
}

// cube drawing function
void SceneManager::DrawCube(float size) {
    float h = size / 2.0f;
    glBegin(GL_QUADS);

    // front
    glNormal3f(0, 0, 1);
    glTexCoord2f(0, 0); glVertex3f(-h, -h, h);
    glTexCoord2f(1, 0); glVertex3f(h, -h, h);
    glTexCoord2f(1, 1); glVertex3f(h, h, h);
    glTexCoord2f(0, 1); glVertex3f(-h, h, h);

    // back
    glNormal3f(0, 0, -1);
    glTexCoord2f(0, 0); glVertex3f(-h, -h, -h);
    glTexCoord2f(1, 0); glVertex3f(-h, h, -h);
    glTexCoord2f(1, 1); glVertex3f(h, h, -h);
    glTexCoord2f(0, 1); glVertex3f(h, -h, -h);

    // left
    glNormal3f(-1, 0, 0);
    glTexCoord2f(0, 0); glVertex3f(-h, -h, -h);
    glTexCoord2f(1, 0); glVertex3f(-h, -h, h);
    glTexCoord2f(1, 1); glVertex3f(-h, h, h);
    glTexCoord2f(0, 1); glVertex3f(-h, h, -h);

    // right
    glNormal3f(1, 0, 0);
    glTexCoord2f(0, 0); glVertex3f(h, -h, -h);
    glTexCoord2f(1, 0); glVertex3f(h, h, -h);
    glTexCoord2f(1, 1); glVertex3f(h, h, h);
    glTexCoord2f(0, 1); glVertex3f(h, -h, h);

    // top
    glNormal3f(0, 1, 0);
    glTexCoord2f(0, 0); glVertex3f(-h, h, -h);
    glTexCoord2f(1, 0); glVertex3f(-h, h, h);
    glTexCoord2f(1, 1); glVertex3f(h, h, h);
    glTexCoord2f(0, 1); glVertex3f(h, h, -h);

    // bottom
    glNormal3f(0, -1, 0);
    glTexCoord2f(0, 0); glVertex3f(-h, -h, -h);
    glTexCoord2f(1, 0); glVertex3f(h, -h, -h);
    glTexCoord2f(1, 1); glVertex3f(h, -h, h);
    glTexCoord2f(0, 1); glVertex3f(-h, -h, h);

    glEnd();
}

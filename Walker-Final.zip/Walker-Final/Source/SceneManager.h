///////////////////////////////////////////////////////////////////////////////
// scenemanager.h
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
// AUTHOR: Jordan Walker
// CS-330 - Aug 15th, 2025
///////////////////////////////////////////////////////////////////////////////

#pragma once
#ifndef SCENEMANAGER_H
#define SCENEMANAGER_H

#include "ShaderManager.h"
#include "ShapeMeshes.h"
#include <glm/glm.hpp>
#include <GL/glew.h>

class SceneManager {
public:
    SceneManager(ShaderManager* pShaderManager);
    ~SceneManager();

    void PrepareScene();
    void RenderScene();

    GLuint LoadTexture(const char* filename);

    // camera
    glm::vec3 cameraPos = glm::vec3(0.0f, 2.0f, 6.0f);
    glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
    glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);

    // projection
    bool  orthographic = false;
    float fov = 45.0f;
    void SetProjectionMode(bool isOrtho) { orthographic = isOrtho; }

private:
    void DrawCube(float size);
    void DrawCylinder(float radius, float height, int segments);
    void DrawCone(float radius, float height, int segments);
    void DrawSphere(float radius, int slices, int stacks);

    ShaderManager* m_pShaderManager;

    // textures
    GLuint floorTexture = 0;
    GLuint wallTexture = 0;
    GLuint cubeTexture = 0;
    GLuint texLaptop = 0;
    GLuint texMetal = 0;

    struct TEXTURE_INFO { GLuint textureID = 0; };
    struct OBJECT_MATERIAL {
        glm::vec3 ambientColor = glm::vec3(1.0f);
        float     ambientStrength = 0.1f;
        glm::vec3 diffuseColor = glm::vec3(1.0f);
        float     diffuseStrength = 1.0f;
        glm::vec3 specularColor = glm::vec3(1.0f);
        float     specularStrength = 0.5f;
        float     shininess = 32.0f;
    };
};

#endif